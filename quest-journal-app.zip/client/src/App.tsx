import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/theme-provider";
import { UserProvider } from "@/components/user-provider";
import { PWAInstallPrompt } from "@/components/pwa-install-prompt";
import { ScrollToTopButton } from "@/components/scroll-to-top-button";

import { useAuth } from "@/hooks/useAuth";
import { useScrollToTop } from "@/hooks/useScrollToTop";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import About from "@/pages/about";
import Contact from "@/pages/contact";
import UserProfile from "@/pages/user-profile";
import Pricing from "@/pages/pricing";
import Forum from "@/pages/forum";
import ForumCategory from "@/pages/forum-category";
import ForumPost from "@/pages/forum-post";
import ForumLeaderboard from "@/pages/forum-leaderboard";
import ForumAdmin from "@/pages/forum-admin";
import AdminPanel from "@/pages/admin-panel";
import AdminDashboard from "@/pages/admin-dashboard";
import ContactMessages from "@/pages/admin/contact-messages";
import ForumManagement from "@/pages/admin/forum-management";
import EntryDetail from "@/pages/entry-detail";
import Entries from "@/pages/entries";
import Vault from "@/pages/vault";
import Landing from "@/pages/landing";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Questionnaire from "@/pages/questionnaire";
import RulesOfTheGame from "@/pages/rules-of-the-game";
import VisionBoard from "@/pages/vision-board";
import VisionArchitect from "@/pages/vision-architect";
import VisionForm from "@/pages/vision-form";
import BlogPage from "@/pages/blog";
import BlogArticlePage from "@/pages/blog-article";
import AdminBlogManagement from "@/pages/admin-blog-management";

function Router() {
  const { isAuthenticated, isLoading, user } = useAuth();
  useScrollToTop(); // This will scroll to top on route changes

  // Show loading screen while authentication is being checked
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary mx-auto"></div>
          <p className="mt-4 text-lg">Loading...</p>
        </div>
      </div>
    );
  }

  // Additional check: if we have a user object, we're authenticated
  const finalIsAuthenticated = isAuthenticated || !!user;

  return (
    <Switch>
      {!finalIsAuthenticated ? (
        <>
          <Route path="/" component={Landing} />
          <Route path="/about" component={About} />
          <Route path="/contact" component={Contact} />
          <Route path="/pricing" component={Pricing} />
          <Route path="/questionnaire" component={Questionnaire} />
          <Route path="/rules" component={RulesOfTheGame} />
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
          <Route component={Landing} /> {/* Redirect unauthenticated users to landing */}
        </>
      ) : (
        <>
          <Route path="/" component={Home} />
          <Route path="/entries" component={Entries} />
          <Route path="/vault" component={Vault} />
          <Route path="/vision-board" component={VisionBoard} />
          <Route path="/vision-architect" component={VisionArchitect} />
          <Route path="/vision-form" component={VisionForm} />
          <Route path="/entry/:id" component={EntryDetail} />
          <Route path="/profile" component={UserProfile} />
          <Route path="/forum" component={Forum} />
          <Route path="/forum/category/:id" component={ForumCategory} />
          <Route path="/forum/post/:id" component={ForumPost} />
          <Route path="/forum/leaderboard" component={ForumLeaderboard} />
          <Route path="/forum/admin" component={ForumAdmin} />
          <Route path="/admin" component={AdminPanel} />
          <Route path="/admin/dashboard" component={AdminDashboard} />
          <Route path="/admin/contact-messages" component={ContactMessages} />
          <Route path="/admin/forum-management" component={ForumManagement} />
          <Route path="/admin/blog-management" component={AdminBlogManagement} />
          <Route path="/blog" component={BlogPage} />
          <Route path="/blog/:slug" component={BlogArticlePage} />
          <Route path="/about" component={About} />
          <Route path="/contact" component={Contact} />
          <Route path="/pricing" component={Pricing} />
          <Route path="/questionnaire" component={Questionnaire} />
          <Route path="/rules" component={RulesOfTheGame} />
          <Route path="/login" component={Login} />
          <Route path="/register" component={Register} />
        </>
      )}
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <UserProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
            <ScrollToTopButton />
            <PWAInstallPrompt />
          </TooltipProvider>
        </UserProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;